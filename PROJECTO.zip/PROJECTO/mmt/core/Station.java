package mmt.core;

import java.util.*;

//FIXME import other classes if necessary

public class Station implements java.io.Serializable {

  /** Serial number for serialization. */
  protected static final long serialVersionUID = 201708301010L;

  protected String _stationName;

}