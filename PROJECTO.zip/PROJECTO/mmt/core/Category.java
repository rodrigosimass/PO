package mmt.core;

import java.util.*;

public abstract class Category implements java.io.Serializable {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 201708301010L;

  protected String _categoryName;

  protected Category(String name){
    _categoryName = name;
  } 

  protected abstract double getDiscount ();
}
