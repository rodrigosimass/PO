package mmt.core;

import java.util.*;

final class Normal extends Category implements java.io.Serializable {

	/** Serial number for serialization. */
	private static final long serialVersionUID = 201708301010L;


	protected Normal() {
		super("NORMAL");

	}

	protected final double getDiscount () {
		return 0;
	}

}