package mmt.core;

import mmt.core.exceptions.BadDateSpecificationException;
import mmt.core.exceptions.BadEntryException;
import mmt.core.exceptions.BadTimeSpecificationException;
import mmt.core.exceptions.InvalidPassengerNameException;
import mmt.core.exceptions.NoSuchDepartureException;
import mmt.core.exceptions.NoSuchPassengerIdException;
import mmt.core.exceptions.NoSuchServiceIdException;
import mmt.core.exceptions.NoSuchStationNameException;
import mmt.core.exceptions.NoSuchItineraryChoiceException;
import mmt.core.exceptions.NonUniquePassengerNameException;
import java.util.*;

public class TrainStops implements java.io.Serializable {

	/** Serial number for serialization. */
	protected static final long serialVersionUID = 201708301010L;

	protected Date _localTime;
	protected SortedMap<Integer, Station> _mapStation;

	protected TrainStops (Date t) {
		_localTime = t;
		_mapStation = new TreeMap();
	}


}
