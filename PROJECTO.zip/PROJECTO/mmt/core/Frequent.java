package mmt.core;

import java.util.*;

final class Frequent extends Category implements java.io.Serializable {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 201708301010L;

  protected Frequent(){
  	super("FREQUENT");

  }

  protected final double getDiscount (){
  	return 0.15;
  }

}