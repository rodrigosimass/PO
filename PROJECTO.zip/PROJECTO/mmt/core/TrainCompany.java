package mmt.core;

import mmt.core.exceptions.BadDateSpecificationException;
import mmt.core.exceptions.BadEntryException;
import mmt.core.exceptions.BadTimeSpecificationException;
import mmt.core.exceptions.InvalidPassengerNameException;
import mmt.core.exceptions.NoSuchDepartureException;
import mmt.core.exceptions.NoSuchPassengerIdException;
import mmt.core.exceptions.NoSuchServiceIdException;
import mmt.core.exceptions.NoSuchStationNameException;
import mmt.core.exceptions.NoSuchItineraryChoiceException;
import mmt.core.exceptions.NonUniquePassengerNameException;
import java.util.*;

//FIXME import other classes if necessary

/**
 * A train company has schedules (services) for its trains and passengers that
 * acquire itineraries based on those schedules.
 */
public class TrainCompany implements java.io.Serializable {

	/** Serial number for serialization. */
	protected static final long serialVersionUID = 201708301010L;

	protected int _nextPassengerID;
	protected SortedMap<Integer, Passenger> _companyMapPassengers;
	protected SortedMap<Integer, Service> _companyMapServices;
	protected SortedMap<Integer, Station> _companyMapStations;
	protected SortedMap<Integer, Itenerary> _companyMapIteneraries;

	protected TrainCompany() {
		_companyMapPassengers = new TreeMap();
		_companyMapServices = new TreeMap();
		_companyMapStations = new TreeMap();
		_companyMapIteneraries = new TreeMap();
		_nextPassengerID = 0;

	}


	//FIXME define fields

	void importFile(String filename) {
		//FIXME implement function
	}

	void registerPassenger(String newName) {
		_companyMapPassengers.put(_nextPassengerID, new Passenger(_nextPassengerID, newName));
		_nextPassengerID++;
	}

	//int requestPassengerId(String name){
	// return _nextPassengerID;
	//}

	void printAllPassengers() {
		for (Map.Entry<Integer, Passenger> entry : _companyMapPassengers.entrySet()) {
			Integer key = entry.getKey();
			Passenger value = entry.getValue();
			System.out.println(key + " => " + value._passengerName);
		}

	}

	Passenger requestPassengerID (int id) throws NoSuchPassengerIdException {
		for (Map.Entry<Integer, Passenger> entry : _companyMapPassengers.entrySet()) {
			Passenger value = entry.getValue();
			if (value._passengerID == id)
				return (value);
		}
		throw new NoSuchPassengerIdException(id);
	}



	/*FIXME
	 * add methods for
	 *   registerPassenger, changePassengerName
	 *   searchItineraries, commitItinerary
	 */

	//FIXME implement other functions if necessary

}
